// UNI addons — кнопки поверх основного расширения. Все тексты на английском.
// 1) UGC item page: real download.
// 2) Game page: fake download with loading + random error.
// 3) Settings: region selector + "Change region" near Account Location (50-70s fake then message).
// 4) Bottom cat menu with dev channel.

(function () {
  if (window.__uniAddons) return;
  window.__uniAddons = true;

  const COUNTRIES = ['Netherlands', 'Germany', 'France', 'Poland', 'Sweden', 'United States', 'Canada', 'Brazil', 'Japan', 'Singapore', 'Australia', 'Indonesia'];

  function whenBody(fn) {
    if (document.body) { fn(); return; }
    document.addEventListener('DOMContentLoaded', fn, { once: true });
  }

  /* ---------- defaults: English + menu on ---------- */

  (function seedDefaults() {
    try {
      chrome.storage.local.get(['uniLanguage'], data => {
        if (!data || !data.uniLanguage) {
          chrome.storage.local.set({ uniLanguage: 'en' });
        }
      });
    } catch (e) { }
  })();
  /* ---------- floating card ---------- */

  let timer = null;

  function showBox(title, mode) {
    const old = document.getElementById('uni-fake');
    if (old) old.remove();
    if (timer) clearInterval(timer);

    const box = document.createElement('div');
    box.id = 'uni-fake';
    box.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483500;'
      + 'width:300px;background:rgba(24,17,36,.97);border:1px solid rgba(107,79,160,.7);border-radius:12px;color:#f2e9ff;'
      + 'font:11.5px/1.4 "Segoe UI",system-ui,sans-serif;box-shadow:0 12px 30px rgba(0,0,0,.5);overflow:hidden';

    const head = document.createElement('div');
    head.style.cssText = 'display:flex;align-items:center;gap:8px;padding:9px 11px;font-weight:700;'
      + 'background:linear-gradient(180deg,#2a1b3d,#251a38);border-bottom:1px solid #3f2c60';
    head.textContent = title;

    const close = document.createElement('span');
    close.style.cssText = 'margin-left:auto;cursor:pointer;color:#9b8ab8';
    close.textContent = '✕';
    close.addEventListener('click', () => box.remove());
    head.appendChild(close);

    const body = document.createElement('div');
    body.style.cssText = 'padding:10px 11px';

    const label = document.createElement('div');
    label.style.cssText = 'display:flex;justify-content:space-between;font-size:11px;color:#c9aaff;margin-bottom:6px';
    const left = document.createElement('span');
    left.textContent = mode === 'download' ? 'Downloading...' : 'Applying...';
    const pct = document.createElement('span');
    pct.textContent = '0%';
    label.appendChild(left);
    label.appendChild(pct);

    const bar = document.createElement('div');
    bar.style.cssText = 'height:7px;border-radius:999px;background:rgba(255,255,255,.08);overflow:hidden';
    const fill = document.createElement('div');
    fill.style.cssText = 'height:100%;width:2%;background:linear-gradient(90deg,#c9aaff,#8f6fd6);border-radius:999px;transition:width .3s';
    bar.appendChild(fill);

    body.appendChild(label);
    body.appendChild(bar);
    box.appendChild(head);
    box.appendChild(body);
    document.body.appendChild(box);

    return { box, fill, pct };
  }

  function runProgress(ui, durationMs, onDone) {
    const started = Date.now();
    if (timer) clearInterval(timer);

    timer = setInterval(() => {
      const ratio = Math.min(1, (Date.now() - started) / durationMs);
      const percent = Math.max(2, Math.min(96, Math.round(ratio * 96)));
      ui.fill.style.width = percent + '%';
      ui.pct.textContent = percent + '%';

      if (ratio >= 1) {
        clearInterval(timer);
        timer = null;
        ui.fill.style.width = '100%';
        ui.pct.textContent = '100%';
        if (onDone) onDone();
      }
    }, 350);
  }

  function addResult(ui, text, ok) {
    if (!ui || !ui.box) return;
    const result = document.createElement('div');
    result.style.cssText = 'margin-top:9px;font-size:11.5px;font-weight:700;line-height:1.4;color:' + (ok ? '#9fe3d0' : '#ff9fb3');
    result.textContent = text;
    ui.box.appendChild(result);
  }

  /* ---------- real asset download ---------- */

  async function downloadAsset(id) {
    const res = await fetch('https://assetdelivery.roblox.com/v1/asset/?id=' + encodeURIComponent(id), {
      credentials: 'include',
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);

    let bytes = new Uint8Array(await res.arrayBuffer());

    if (bytes[0] === 0x1f && bytes[1] === 0x8b && typeof DecompressionStream !== 'undefined') {
      try {
        const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
        bytes = new Uint8Array(await new Response(stream).arrayBuffer());
      } catch (e) { }
    }

    const blob = new Blob([bytes], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'roblox-uni/' + id + '.rbxm';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000);

    return bytes.length;
  }

  /* ---------- buttons ---------- */

  function makeButton(text, onClick) {
    const btn = document.createElement('div');
    btn.className = 'uni-addon-btn';
    btn.textContent = text;
    btn.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;gap:6px;'
      + 'padding:5px 10px;margin:4px 4px 4px 0;border-radius:8px;cursor:pointer;font-weight:600;font-size:10.5px;'
      + 'color:#d9c9f5;background:rgba(27,19,41,.82);border:1px solid rgba(107,79,160,.6);'
      + 'opacity:.62;transition:opacity .15s ease,border-color .15s ease';
    btn.addEventListener('click', onClick);
    return btn;
  }

  function floating(btn, id) {
    btn.id = id;
    btn.style.position = 'fixed';
    btn.style.right = '12px';
    btn.style.bottom = '76px';
    btn.style.zIndex = '2147482800';
    btn.style.margin = '0';
    btn.addEventListener('mouseenter', () => { btn.style.opacity = '1'; btn.style.borderColor = '#c9aaff'; });
    btn.addEventListener('mouseleave', () => { btn.style.opacity = '.62'; btn.style.borderColor = 'rgba(107,79,160,.6)'; });
    document.body.appendChild(btn);
  }

  function ensureUgcButton() {
    const match = location.pathname.match(/\/(catalog|library)\/(\d+)/);
    if (!match || document.getElementById('uni-ugc-dl')) return;

    const id = match[2];
    const btn = makeButton('Download item', async () => {
      const ui = showBox('Item download', 'download');
      try {
        const size = await downloadAsset(id);
        ui.fill.style.width = '100%';
        ui.pct.textContent = '100%';
        addResult(ui, 'Saved · ' + Math.round(size / 1024) + ' KB', true);
      } catch (error) {
        ui.fill.style.width = '100%';
        ui.pct.textContent = '100%';
        addResult(ui, 'Asset unavailable (code: 0x51A)', false);
      }
    });

    floating(btn, 'uni-ugc-dl');
  }

  function ensureGameButton() {
    if (!/^\/games\/\d+/.test(location.pathname) || document.getElementById('uni-game-dl')) return;

    const btn = makeButton('Download game', () => {
      const ui = showBox('Game download', 'download');
      runProgress(ui, 120000, () => {
        const errors = [
          'Failed: connection to asset server lost (code: 0x2F7)',
          'Failed: game is protected (code: 0x3C1)',
          'Failed: download limit reached (code: 0x41D)',
          'Failed: package damaged (code: 0x5B2)',
        ];
        addResult(ui, errors[Math.floor(Math.random() * errors.length)], false);
      });
    });

    floating(btn, 'uni-game-dl');
  }

  function ensureSettingsBlock() {
    if (!/\/my\/(account|settings|info)/i.test(location.pathname) && !/^\/settings/i.test(location.pathname)) return;
    if (document.getElementById('uni-settings-box')) return;

    const box = document.createElement('div');
    box.id = 'uni-settings-box';
    box.style.cssText = 'margin:14px 0;padding:12px;border:1px solid #3f2c60;border-radius:12px;'
      + 'background:rgba(27,19,41,.92);color:#f2e9ff;font:12px/1.4 "Segoe UI",system-ui,sans-serif';

    const title = document.createElement('div');
    title.style.cssText = 'font-weight:700;margin-bottom:8px';
    title.textContent = 'Account region';
    box.appendChild(title);

    const select = document.createElement('select');
    select.id = 'uni-region-select';
    select.style.cssText = 'width:100%;margin-bottom:8px;padding:8px;border-radius:9px;border:1px solid #3f2c60;'
      + 'background:#241a38;color:#f2e9ff;font:12px "Segoe UI",sans-serif';
    COUNTRIES.forEach(name => {
      const option = document.createElement('option');
      option.value = name;
      option.textContent = name;
      select.appendChild(option);
    });
    box.appendChild(select);

    box.appendChild(makeButton('Change region', () => {
      const ui = showBox('Region change', 'apply');
      runProgress(ui, 55000 + Math.random() * 15000, () => {
        addResult(ui, 'You must not play any games and stay out of Roblox for a couple of hours for the change to apply.', true);
      });
    }));

    let anchor = null;
    const nodes = document.querySelectorAll('div,section,li,span,h2,h3,p');
    for (const node of nodes) {
      if (node.children.length > 3) continue;
      const text = (node.textContent || '').trim();
      if (!text || text.length > 60) continue;
      if (/account location|location|region/i.test(text)) {
        anchor = node.closest('div,section,li') || node.parentElement;
        break;
      }
    }

    if (anchor && anchor.parentElement) anchor.parentElement.insertBefore(box, anchor.nextSibling);
    else {
      const main = document.querySelector('main') || document.querySelector('#container-main') || document.body;
      main.insertBefore(box, main.firstChild);
    }
  }

  /* ---------- cat menu ---------- */

  function ensureMenu() {
    if (document.getElementById('uni-menu') || !document.body) return;

    const menu = document.createElement('div');
    menu.id = 'uni-menu';
    menu.style.cssText = 'position:fixed;left:10px;bottom:8px;z-index:2147482000;display:inline-flex;align-items:center;'
      + 'gap:7px;padding:4px 8px;border-radius:999px;color:#f2e9ff;opacity:.55;'
      + 'background:rgba(24,17,36,.85);border:1px solid rgba(107,79,160,.55);'
      + 'font:10px/1.15 "Segoe UI",system-ui,sans-serif;transition:opacity .15s ease';

    const cat = document.createElement('pre');
    cat.style.cssText = 'margin:0;color:#c9aaff;font:8px/1 "Cascadia Mono",Consolas,monospace';
    cat.textContent = ' /\\_/\\' + String.fromCharCode(10) + '( o.o )' + String.fromCharCode(10) + ' > ^ <';

    const info = document.createElement('div');
    const name = document.createElement('div');
    name.style.cssText = 'font-weight:700;font-size:11px';
    name.textContent = 'Roblox Uni';
    const link = document.createElement('a');
    link.href = 'https://t.me/UNI_EXT';
    link.target = '_blank';
    link.rel = 'noopener';
    link.style.cssText = 'color:#b9a4e0;text-decoration:none;font-size:10.5px';
    link.textContent = 'dev channel';
    info.appendChild(name);
    info.appendChild(link);

    const close = document.createElement('span');
    close.style.cssText = 'cursor:pointer;color:#7d6a9c;font-size:10px';
    close.textContent = '✕';
    close.addEventListener('click', () => menu.remove());

    menu.appendChild(cat);
    menu.appendChild(info);
    menu.appendChild(close);
    menu.addEventListener('mouseenter', () => { menu.style.opacity = '1'; });
    menu.addEventListener('mouseleave', () => { menu.style.opacity = '.55'; });
    document.body.appendChild(menu);

    let dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;
    menu.addEventListener('mousedown', ev => {
      if (ev.target === close) return;
      const rect = menu.getBoundingClientRect();
      ox = rect.left; oy = rect.top; sx = ev.clientX; sy = ev.clientY;
      dragging = true;
      menu.style.left = ox + 'px'; menu.style.top = oy + 'px'; menu.style.bottom = 'auto';
      ev.preventDefault();
    });
    window.addEventListener('mousemove', ev => {
      if (!dragging) return;
      menu.style.left = Math.max(4, ox + ev.clientX - sx) + 'px';
      menu.style.top = Math.max(4, oy + ev.clientY - sy) + 'px';
    });
    window.addEventListener('mouseup', () => { dragging = false; });
  }

  function tick() {
    if (!document.body) return;
    ensureUgcButton();
    ensureGameButton();
    ensureSettingsBlock();
    ensureMenu();
  }

  whenBody(tick);
  setInterval(tick, 1500);
})();
