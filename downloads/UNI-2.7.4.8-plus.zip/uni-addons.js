// UNI addons — кнопки поверх основного расширения. Все тексты на английском.
// 1) UGC item page: real download.
// 2) Game page: fake download with loading + random error.
// 3) Settings: region selector + "Change region" near Account Location (50-70s fake then message).
// 4) Bottom cat menu with dev channel.

(function () {
  if (window.__uniAddons) return;
  window.__uniAddons = true;

  const COUNTRIES = ['Netherlands', 'Germany', 'France', 'Poland', 'Sweden', 'United States', 'Canada', 'Brazil', 'Japan', 'Singapore', 'Australia', 'Indonesia'];

  function whenBody(fn) {
    if (document.body) { fn(); return; }
    document.addEventListener('DOMContentLoaded', fn, { once: true });
  }

  /* ---------- defaults: English + menu on ---------- */

  (function seedDefaults() {
    try {
      chrome.storage.local.get(['uniLanguage'], data => {
        if (!data || !data.uniLanguage) {
          chrome.storage.local.set({ uniLanguage: 'en' });
        }
      });
    } catch (e) { }
  })();
  /* ---------- floating card ---------- */

  let timer = null;

  function showBox(title, mode) {
    const old = document.getElementById('uni-fake');
    if (old) old.remove();
    if (timer) clearInterval(timer);

    const box = document.createElement('div');
    box.id = 'uni-fake';
    box.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483500;'
      + 'width:300px;color:#f1edf4;border:1px solid #1d1d29;border-radius:18px;' +
      'background:radial-gradient(130% 90% at 50% -35%, rgba(122,23,216,.22), transparent 62%), linear-gradient(180deg,rgba(255,255,255,.055),rgba(255,255,255,.012)), #0b0b12;'
      + 'font:11.5px/1.4 "Segoe UI",system-ui,sans-serif;box-shadow:0 12px 30px rgba(0,0,0,.5);overflow:hidden';

    const head = document.createElement('div');
    head.style.cssText = 'display:flex;align-items:center;gap:8px;padding:9px 11px;font-weight:700;'
      + 'background:rgba(0,0,0,.72);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);'
      + 'border-bottom:1px solid rgba(255,255,255,.06)';
    head.textContent = title;

    const close = document.createElement('span');
    close.style.cssText = 'margin-left:auto;cursor:pointer;color:#9b8ab8';
    close.textContent = '✕';
    close.addEventListener('click', () => box.remove());
    head.appendChild(close);

    const body = document.createElement('div');
    body.style.cssText = 'padding:10px 11px';

    const label = document.createElement('div');
    label.style.cssText = 'display:flex;justify-content:space-between;font-size:11px;color:#c9aaff;margin-bottom:6px';
    const left = document.createElement('span');
    left.textContent = mode === 'download' ? 'Downloading...' : 'Applying...';
    const pct = document.createElement('span');
    pct.textContent = '0%';
    label.appendChild(left);
    label.appendChild(pct);

    const bar = document.createElement('div');
    bar.style.cssText = 'height:7px;border-radius:999px;background:rgba(255,255,255,.08);overflow:hidden';
    const fill = document.createElement('div');
    fill.style.cssText = 'height:100%;width:2%;background:linear-gradient(118deg,#4a35ff,#8a1ce0 26%,#cf1395 48%,#f52c3f 70%,#ff8a2b 88%,#ffd45a);border-radius:999px;transition:width .3s';
    bar.appendChild(fill);

    body.appendChild(label);
    body.appendChild(bar);
    box.appendChild(head);
    box.appendChild(body);
    document.body.appendChild(box);

    return { box, fill, pct };
  }

  function runProgress(ui, durationMs, onDone) {
    const started = Date.now();
    if (timer) clearInterval(timer);

    timer = setInterval(() => {
      const ratio = Math.min(1, (Date.now() - started) / durationMs);
      const percent = Math.max(2, Math.min(96, Math.round(ratio * 96)));
      ui.fill.style.width = percent + '%';
      ui.pct.textContent = percent + '%';

      if (ratio >= 1) {
        clearInterval(timer);
        timer = null;
        ui.fill.style.width = '100%';
        ui.pct.textContent = '100%';
        if (onDone) onDone();
      }
    }, 350);
  }

  function addResult(ui, text, ok) {
    if (!ui || !ui.box) return;
    const result = document.createElement('div');
    result.style.cssText = 'margin-top:9px;font-size:11.5px;font-weight:700;line-height:1.4;color:' + (ok ? '#9fe3d0' : '#ff9fb3');
    result.textContent = text;
    ui.box.appendChild(result);
  }

  /* ---------- real asset download ---------- */

  async function downloadAsset(id) {
    const res = await fetch('https://assetdelivery.roblox.com/v1/asset/?id=' + encodeURIComponent(id), {
      credentials: 'include',
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);

    let bytes = new Uint8Array(await res.arrayBuffer());

    if (bytes[0] === 0x1f && bytes[1] === 0x8b && typeof DecompressionStream !== 'undefined') {
      try {
        const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
        bytes = new Uint8Array(await new Response(stream).arrayBuffer());
      } catch (e) { }
    }

    const blob = new Blob([bytes], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'roblox-uni/' + id + '.rbxm';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000);

    return bytes.length;
  }

  /* ---------- buttons ---------- */

  function makeButton(text, onClick) {
    const btn = document.createElement('div');
    btn.className = 'uni-addon-btn';
    btn.textContent = text;
    btn.style.cssText = 'display:inline-flex;align-items:center;justify-content:center;gap:6px;'
      + 'padding:6px 11px;margin:4px 4px 4px 0;border-radius:14px;cursor:pointer;font-weight:700;font-size:10.5px;'
      + 'color:#f1edf4;background:rgba(255,255,255,.04);border:1px solid #1d1d29;'
      + 'opacity:.6;transition:opacity .15s ease,border-color .15s ease,transform .15s ease,background .15s ease';
    btn.addEventListener('click', onClick);
    return btn;
  }

  function floating(btn, id) {
    btn.id = id;
    btn.style.position = 'fixed';
    btn.style.right = '12px';
    btn.style.bottom = '76px';
    btn.style.zIndex = '2147482800';
    btn.style.margin = '0';
    btn.addEventListener('mouseenter', () => {
      btn.style.opacity = '1';
      btn.style.borderColor = '#2f2f40';
      btn.style.background = 'rgba(255,255,255,.07)';
      btn.style.transform = 'translateY(-1px)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.opacity = '.6';
      btn.style.borderColor = '#1d1d29';
      btn.style.background = 'rgba(255,255,255,.04)';
      btn.style.transform = 'none';
    });
    document.body.appendChild(btn);
  }

  function ensureUgcButton() {
    const match = location.pathname.match(/\/(catalog|library)\/(\d+)/);
    if (!match || document.getElementById('uni-ugc-dl')) return;

    const id = match[2];
    const btn = makeButton('Download item', async () => {
      const ui = showBox('Item download', 'download');
      try {
        const size = await downloadAsset(id);
        ui.fill.style.width = '100%';
        ui.pct.textContent = '100%';
        addResult(ui, 'Saved · ' + Math.round(size / 1024) + ' KB', true);
      } catch (error) {
        ui.fill.style.width = '100%';
        ui.pct.textContent = '100%';
        addResult(ui, 'Asset unavailable (code: 0x51A)', false);
      }
    });

    floating(btn, 'uni-ugc-dl');
  }

  function ensureGameButton() {
    if (!/^\/games\/\d+/.test(location.pathname) || document.getElementById('uni-game-dl')) return;

    const btn = makeButton('Download game', () => {
      const ui = showBox('Game download', 'download');
      runProgress(ui, 120000, () => {
        const errors = [
          'Failed: connection to asset server lost (code: 0x2F7)',
          'Failed: game is protected (code: 0x3C1)',
          'Failed: download limit reached (code: 0x41D)',
          'Failed: package damaged (code: 0x5B2)',
        ];
        addResult(ui, errors[Math.floor(Math.random() * errors.length)], false);
      });
    });

    floating(btn, 'uni-game-dl');
  }

  function ensureSettingsBlock() {
    if (!/\/my\/(account|settings|info)/i.test(location.pathname) && !/^\/settings/i.test(location.pathname)) return;
    if (document.getElementById('uni-settings-box')) return;

    const box = document.createElement('div');
    box.id = 'uni-settings-box';
    box.style.cssText = 'margin:14px 0;padding:12px;border:1px solid #1d1d29;border-radius:18px;'
      + 'background:radial-gradient(130% 90% at 50% -35%, rgba(122,23,216,.22), transparent 62%), linear-gradient(180deg,rgba(255,255,255,.055),rgba(255,255,255,.012)), #0b0b12;'
      + 'color:#f1edf4;font:12px/1.4 "Inter","Segoe UI",system-ui,sans-serif';

    const title = document.createElement('div');
    title.style.cssText = 'font-weight:700;margin-bottom:8px';
    title.textContent = 'Account region';
    box.appendChild(title);

    const select = document.createElement('select');
    select.id = 'uni-region-select';
    select.style.cssText = 'width:100%;margin-bottom:8px;padding:8px;border-radius:9px;border:1px solid #3f2c60;'
      + 'background:#070709;color:#f1edf4;font:12px system-ui,sans-serif';
    COUNTRIES.forEach(name => {
      const option = document.createElement('option');
      option.value = name;
      option.textContent = name;
      select.appendChild(option);
    });
    box.appendChild(select);

    box.appendChild(makeButton('Change region', () => {
      const ui = showBox('Region change', 'apply');
      runProgress(ui, 55000 + Math.random() * 15000, () => {
        addResult(ui, 'You must not play any games and stay out of Roblox for a couple of hours for the change to apply.', true);
      });
    }));

    let anchor = null;
    const nodes = document.querySelectorAll('div,section,li,span,h2,h3,p');
    for (const node of nodes) {
      if (node.children.length > 3) continue;
      const text = (node.textContent || '').trim();
      if (!text || text.length > 60) continue;
      if (/account location|location|region/i.test(text)) {
        anchor = node.closest('div,section,li') || node.parentElement;
        break;
      }
    }

    if (anchor && anchor.parentElement) anchor.parentElement.insertBefore(box, anchor.nextSibling);
    else {
      const main = document.querySelector('main') || document.querySelector('#container-main') || document.body;
      main.insertBefore(box, main.firstChild);
    }
  }


  /* ---------- UNI mode: чёрный фон + радужный логотип ---------- */

  const UNI_MODE_STYLE_ID = 'uni-mode-style';
  const UNI_MODE_LOGO_ID = 'uni-mode-logo';

  function applyUniMode(on) {
    const oldStyle = document.getElementById(UNI_MODE_STYLE_ID);
    const legacyLogo = document.getElementById(UNI_MODE_LOGO_ID);

    if (legacyLogo) legacyLogo.remove();
    document.querySelectorAll('[data-uni-mode-hidden]').forEach(el => {
      el.style.display = '';
      el.removeAttribute('data-uni-mode-hidden');
    });

    if (!on) {
      if (oldStyle) oldStyle.remove();
      return;
    }

    const wordmark = chrome.runtime.getURL('public/Assets/uni-wordmark.png');

    const style = oldStyle || document.createElement('style');
    style.id = UNI_MODE_STYLE_ID;
    style.textContent = [
      /* токены Roblox */
      'html, :root {',
      '  --color-surface-0: #06060a !important;',
      '  --color-surface-100: #050508 !important;',
      '  --color-surface-200: #050508 !important;',
      '  --color-surface-300: #0a0a0f !important;',
      '  --color-common-navigation-bar: #050508 !important;',
      '  --color-stroke-default: #1d1d29 !important;',
      '  --color-content-default: #f1edf4 !important;',
      '}',
      'html, body { background: #06060a !important; color-scheme: dark; }',
      '#wrap, #container-main, .container-main, main, #contents { background: #06060a !important; }',
      '.content, .page-content, [class*="page-content"], [class*="home-page"] { background: transparent !important; }',

      /* навбар, сайдбар */
      '#navigation, .rbx-navbar, #header, header, [class*="navigation-bar"] { background: #050508 !important; border-bottom: 1px solid #0d0d12 !important; }',
      '#left-navigation, .left-nav, .left-column, [class*="left-navigation"] { background: #050508 !important; }',

      /* поиск */
      '[class*="search"], [class*="Search"] { background-color: #0d0d13 !important; }',
      'input[type="search"], #navbar-search-input, [class*="search"] input { background: #0d0d13 !important; color: #f1edf4 !important; border: 1px solid #15151d !important; }',

      /* меню/модалки */
      '[role="menu"], [class*="menu-item"], [class*="dropdown"] { background: #0a0a10 !important; }',
      '[role="dialog"], [class*="modal"] { background: #08080d !important; border: 1px solid #15151d !important; }',
      '[class*="card"], [class*="section"], [class*="panel"] { border-color: #1d1d29 !important; }',

      /* страница настроек UNI (RoValra) */
      '.uni-settings-page, .uni-settings, .uni-settings-loading { background: #06060a !important; }',
      '.uni-settings-page [class*="card"], .uni-settings [class*="card"],',
      '.uni-settings-page [class*="section"], .uni-settings [class*="section"],',
      '.uni-settings-page [class*="panel"], .uni-settings [class*="panel"] { background: #08080d !important; border-color: #15151d !important; }',
      '.uni-settings-page [class*="nav"], .uni-settings [class*="nav"],',
      '.uni-settings-page [class*="sidebar"], .uni-settings [class*="sidebar"] { background: #050508 !important; }',
      '.uni-settings-page input, .uni-settings-page select, .uni-settings-page textarea,',
      '.uni-settings input, .uni-settings select, .uni-settings textarea {',
      '  background: #0d0d13 !important; color: #f1edf4 !important; border: 1px solid #15151d !important;',
      '}',
      '[class*="uni-settings-search"] input { min-width: 0 !important; width: 100% !important; }',

      /* UNI добавляется после логотипа Roblox */
      'a[href="/home"], #nav-logo-link {',
      '  vertical-align: middle !important;',
      '}',
      'a[href="/home"]::after, #nav-logo-link::after {',
      '  content: "" !important;',
      '  display: inline-block !important;',
      '  vertical-align: middle !important;',
      '  width: 48px !important;',
      '  height: 18px !important;',
      '  margin: 1px 10px 0 9px !important;',
      '  transform: translateY(0) !important;',
      '  background-image: url("' + wordmark + '") !important;',
      '  background-repeat: no-repeat !important;',
      '  background-position: center !important;',
      '  background-size: contain !important;',
      '}',
    ].join('\n');

    if (!oldStyle) (document.head || document.documentElement).appendChild(style);
  }

  let uniModeOn = false;

  function keepUniMode() {
    if (!uniModeOn) return;
    if (!document.getElementById(UNI_MODE_STYLE_ID)) {
      applyUniMode(true);
      return;
    }
    if (!document.getElementById(UNI_MODE_LOGO_ID)) {
      applyUniMode(true);
    }
  }

  function loadUniMode() {
    try {
      chrome.storage.local.get({ uniMode: true }, data => {
        uniModeOn = data.uniMode !== false;
        applyUniMode(uniModeOn);
        setInterval(keepUniMode, 3000);
      });
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local' || !changes.uniMode) return;
        uniModeOn = Boolean(changes.uniMode.newValue);
        applyUniMode(uniModeOn);
      });
    } catch (e) { }
  }

  loadUniMode();

  /* ---------- cat menu ---------- */

  function ensureMenu() {
    if (document.getElementById('uni-menu') || !document.body) return;

    const menu = document.createElement('div');
    menu.id = 'uni-menu';
    menu.style.cssText = 'position:fixed;left:10px;bottom:8px;z-index:2147482000;display:inline-flex;align-items:center;'
      + 'gap:7px;padding:4px 8px;border-radius:999px;color:#f1edf4;opacity:.55;'
      + 'background:rgba(0,0,0,.72);backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.06);'
      + 'font:10px/1.15 "Inter","Segoe UI",system-ui,sans-serif;transition:opacity .15s ease';

    const cat = document.createElement('pre');
    cat.style.cssText = 'margin:0;color:#c9aaff;font:8px/1 "Cascadia Mono",Consolas,monospace';
    cat.textContent = ' /\\_/\\' + String.fromCharCode(10) + '( o.o )' + String.fromCharCode(10) + ' > ^ <';

    const info = document.createElement('div');
    const name = document.createElement('div');
    name.style.cssText = 'font-weight:700;font-size:11px';
    name.textContent = 'Roblox Uni';
    const link = document.createElement('a');
    link.href = 'https://t.me/UNI_EXT';
    link.target = '_blank';
    link.rel = 'noopener';
    link.style.cssText = 'color:#b9a4e0;text-decoration:none;font-size:10.5px';
    link.textContent = 'dev channel';
    info.appendChild(name);
    info.appendChild(link);

    const close = document.createElement('span');
    close.style.cssText = 'cursor:pointer;color:#7d6a9c;font-size:10px';
    close.textContent = '✕';
    close.addEventListener('click', () => menu.remove());

    menu.appendChild(cat);
    menu.appendChild(info);
    menu.appendChild(close);
    menu.addEventListener('mouseenter', () => { menu.style.opacity = '1'; });
    menu.addEventListener('mouseleave', () => { menu.style.opacity = '.55'; });
    document.body.appendChild(menu);

    let dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;
    menu.addEventListener('mousedown', ev => {
      if (ev.target === close) return;
      const rect = menu.getBoundingClientRect();
      ox = rect.left; oy = rect.top; sx = ev.clientX; sy = ev.clientY;
      dragging = true;
      menu.style.left = ox + 'px'; menu.style.top = oy + 'px'; menu.style.bottom = 'auto';
      ev.preventDefault();
    });
    window.addEventListener('mousemove', ev => {
      if (!dragging) return;
      menu.style.left = Math.max(4, ox + ev.clientX - sx) + 'px';
      menu.style.top = Math.max(4, oy + ev.clientY - sy) + 'px';
    });
    window.addEventListener('mouseup', () => { dragging = false; });
  }

  function tick() {
    if (!document.body) return;
    ensureUgcButton();
    ensureGameButton();
    ensureMenu();
  }

  whenBody(tick);
  setInterval(tick, 1500);
})();
