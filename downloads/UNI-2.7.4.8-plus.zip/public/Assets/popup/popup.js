/*!
 * Roblox Uni popup (base: RoValra 2.7.3, GPL-3.0) — English UI.
 */
document.addEventListener('DOMContentLoaded', function () {
  const $ = id => document.getElementById(id);

  /* ---------- версия ---------- */
  try {
    const version = chrome.runtime.getManifest().version;
    const el = $('version');
    if (el) el.textContent = 'version ' + version;
  } catch (e) { }

  /* ---------- вкладки ---------- */
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t === tab));
      const name = tab.getAttribute('data-tab');
      document.querySelectorAll('.panel').forEach(panel => {
        panel.classList.toggle('active', panel.id === 'panel-' + name);
      });
    });
  });

  /* ---------- ссылки меню ---------- */
  const links = {
    'settings-link': 'https://www.roblox.com/my/account?uni=info#!/info',
    'dev-link': 'https://t.me/UNI_EXT',
  };
  Object.keys(links).forEach(id => {
    const el = $(id);
    if (!el) return;
    el.addEventListener('click', () => chrome.tabs.create({ url: links[id] }));
  });

  /* ---------- утилиты ---------- */
  const COUNTRIES = ['Netherlands', 'Germany', 'France', 'Poland', 'Sweden', 'United States', 'Canada', 'Brazil', 'Japan', 'Singapore', 'Australia', 'Indonesia'];

  function showBar(barId, noteId, start) {
    const bar = $(barId);
    const note = $(noteId);
    const fill = bar && bar.querySelector('div');
    if (bar) bar.style.display = start ? 'block' : 'none';
    if (fill && start) fill.style.width = '2%';
    if (note) { note.style.display = 'none'; note.textContent = ''; }
    return { bar, fill, note };
  }

  function runProgress(barId, noteId, durationMs, onDone) {
    const ui = showBar(barId, noteId, true);
    const started = Date.now();
    const timer = setInterval(() => {
      const ratio = Math.min(1, (Date.now() - started) / durationMs);
      const percent = Math.max(2, Math.min(97, Math.round(ratio * 97)));
      if (ui.fill) ui.fill.style.width = percent + '%';
      if (ratio >= 1) {
        clearInterval(timer);
        if (ui.fill) ui.fill.style.width = '100%';
        if (onDone) onDone(ui.note);
      }
    }, 320);
    return timer;
  }

  function note(el, text, ok) {
    if (!el) return;
    el.style.display = 'block';
    el.style.color = ok ? '#9fe3d0' : '#ff9fb3';
    el.textContent = text;
  }

  async function api(url) {
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return res.json();
  }

  /* ---------- shaders ---------- */
  const shadersBtn = $('shaders-btn');
  if (shadersBtn) {
    shadersBtn.addEventListener('click', () => {
      shadersBtn.disabled = true;
      runProgress('shaders-bar', 'shaders-note', 3200, uiNote => {
        note(uiNote, 'Shaders enabled.', true);
        shadersBtn.disabled = false;
      });
    });
  }

  /* ---------- текущая вкладка ---------- */
  let currentUrl = '';
  let ugcId = null;
  let gamePlaceId = null;

  async function loadCurrentTab() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      currentUrl = (tab && tab.url) || '';

      const ugc = currentUrl.match(/roblox\.com\/(?:catalog|library)\/(\d+)/);
      ugcId = ugc ? ugc[1] : null;

      const game = currentUrl.match(/roblox\.com\/games\/(\d+)/);
      gamePlaceId = game ? game[1] : null;
    } catch (e) { }

    // UGC
    const ugcHint = $('ugc-hint');
    const ugcBtn = $('ugc-btn');
    if (ugcId) {
      if (ugcHint) ugcHint.textContent = 'Item ID: ' + ugcId;
      if (ugcBtn) ugcBtn.disabled = false;
    } else {
      if (ugcHint) ugcHint.textContent = 'Open a UGC item page to download it.';
      if (ugcBtn) ugcBtn.disabled = true;
    }

    // игра
    const gameBtn = $('game-btn');
    const gameName = $('game-name');
    const gameIdEl = $('game-id');
    const gameIcon = $('game-icon');

    if (gameIcon && !gamePlaceId) { gameIcon.style.display = 'none'; }

    if (gamePlaceId) {
      if (gameIdEl) gameIdEl.textContent = 'Place ID: ' + gamePlaceId;
      if (gameBtn) gameBtn.disabled = false;
      if (gameIcon) gameIcon.style.display = 'block';

      try {
        const uni = await api('https://apis.roblox.com/universes/v1/places/' + gamePlaceId + '/universe');
        if (uni && uni.universeId) {
          const info = await api('https://games.roblox.com/v1/games?universeIds=' + uni.universeId);
          const data = info && info.data && info.data[0];
          if (data && gameName) gameName.textContent = data.name || 'Game';

          try {
            const icons = await api('https://thumbnails.roblox.com/v1/games/icons?universeIds=' + uni.universeId + '&size=150x150&format=Png');
            const icon = icons && icons.data && icons.data[0] && icons.data[0].imageUrl;
            if (gameIcon) {
              if (icon) {
                gameIcon.src = icon;
                gameIcon.style.display = 'block';
              } else {
                gameIcon.removeAttribute('src');
                gameIcon.style.display = 'none';
              }
            }
          } catch (e) { }
        }
      } catch (e) { }

      if (gameIcon && !gameIcon.getAttribute('src')) gameIcon.style.display = 'none';

      // список регионов, а не серверов игры
    } else {
      if (gameIcon) gameIcon.style.display = 'none';
      if (gameName) gameName.textContent = 'No game detected';
      if (gameIdEl) gameIdEl.textContent = 'Open a game page';
      if (gameBtn) gameBtn.disabled = true;
    }
  }

  /* ---------- UGC download ---------- */
  const ROBUX = 'R' + String.fromCharCode(36);

  async function toDataUrl(id) {
    const res = await fetch('https://assetdelivery.roblox.com/v1/asset/?id=' + encodeURIComponent(id), { credentials: 'include' });
    if (!res.ok) throw new Error('HTTP ' + res.status);

    let bytes = new Uint8Array(await res.arrayBuffer());
    if (bytes[0] === 0x1f && bytes[1] === 0x8b && typeof DecompressionStream !== 'undefined') {
      try {
        const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
        bytes = new Uint8Array(await new Response(stream).arrayBuffer());
      } catch (e) { }
    }

    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }

    return { dataUrl: 'data:application/octet-stream;base64,' + btoa(binary), size: bytes.length };
  }

  const ugcBtn = $('ugc-btn');
  if (ugcBtn) {
    ugcBtn.addEventListener('click', async () => {
      if (!ugcId) return;
      ugcBtn.disabled = true;
      const bar = showBar('ugc-bar', 'ugc-note', true);
      const timer = setInterval(() => {
        if (bar.fill) {
          const width = parseFloat(bar.fill.style.width) || 2;
          bar.fill.style.width = Math.min(92, width + 7) + '%';
        }
      }, 220);

      try {
        const result = await toDataUrl(ugcId);
        clearInterval(timer);
        if (bar.fill) bar.fill.style.width = '100%';
        await chrome.downloads.download({
          url: result.dataUrl,
          filename: 'roblox-uni/' + ugcId + '.rbxm',
          saveAs: false,
        });
        note(bar.note, 'Saved · ' + Math.round(result.size / 1024) + ' KB', true);
      } catch (e) {
        clearInterval(timer);
        if (bar.fill) bar.fill.style.width = '100%';
        note(bar.note, 'Asset unavailable (code: 0x51A)', false);
      }
      ugcBtn.disabled = false;
    });
  }

  /* ---------- game download (fake) ---------- */
  const gameBtn = $('game-btn');
  if (gameBtn) {
    gameBtn.addEventListener('click', () => {
      if (!gamePlaceId) return;
      gameBtn.disabled = true;
      runProgress('game-bar', 'game-note', 110000, uiNote => {
        const errors = [
          'Failed: connection to asset server lost (code: 0x2F7)',
          'Failed: game is protected (code: 0x3C1)',
          'Failed: download limit reached (code: 0x41D)',
          'Failed: package damaged (code: 0x5B2)',
        ];
        note(uiNote, errors[Math.floor(Math.random() * errors.length)], false);
        gameBtn.disabled = false;
      });
    });
  }

  /* ---------- region ---------- */
  const regionSelect = $('region-select');

  if (regionSelect) {
    COUNTRIES.forEach(name => {
      const option = document.createElement('option');
      option.value = name;
      option.textContent = name;
      regionSelect.appendChild(option);
    });
  }

  const regionBtn = $('region-btn');
  if (regionBtn) {
    regionBtn.addEventListener('click', () => {
      regionBtn.disabled = true;
      runProgress('region-bar', 'region-note', 55000 + Math.random() * 15000, uiNote => {
        note(uiNote, 'You must not play any games and stay out of Roblox for a couple of hours for the change to apply.', true);
        regionBtn.disabled = false;
      });
    });
  }

  /* ---------- UNI mode ---------- */
  const modeToggle = document.getElementById('uni-mode-toggle');
  if (modeToggle) {
    chrome.storage.local.get({ uniMode: true }, data => {
      modeToggle.checked = data.uniMode !== false;
    });
    modeToggle.addEventListener('change', () => {
      chrome.storage.local.set({ uniMode: modeToggle.checked });
    });
  }

  loadCurrentTab();
});
