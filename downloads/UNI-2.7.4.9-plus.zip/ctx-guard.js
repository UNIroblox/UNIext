// Глушилка шума в консоли Roblox-страницы.
// Грузится первым (content_scripts[0], document_start), поэтому успевает
// перехватить console раньше остальных скриптов расширения.
//
// Что делает:
//  1) убирает известный безвредный шум (мёртвые эндпоинты RoValra, Three.js,
//     "Extension context invalidated" после перезагрузки расширения);
//  2) не даёт упасть вызовам chrome.*, когда контекст расширения уже мёртв.
// Логику скриптов не меняет: всё, что не попало под фильтр, печатается как обычно.
(() => {
  // --- 1. фильтр сообщений -------------------------------------------------
  const NOISE = [
    /Extension context invalidated/i,
    /Failed to fetch/i,
    /Multiple instances of Three\.js/i,
    /^THREE\./,
    /rovalra\.com/i,
    /status-page/i,
    /cloud-authentication\/v1\/apiKey/i,
    /authenticated user language/i,
    /refresh remote settings config/i,
    /voice ban status/i,
    /status page is down/i,
    /^UNI[\s:]/,
    /^UNI$/,
    /^\[sdui-core\]/,
    /RegistryCompositionWarning/,
    /^The namespace /,
    /ApolloClient/,
    /go\.apollo\.dev\/c\/err/,
  ];

  try {
    const levels = ['error', 'warn', 'info', 'log', 'debug'];
    for (const level of levels) {
      const orig = console[level];
      if (typeof orig !== 'function') continue;
      console[level] = function (...args) {
        try {
          const text = args.map(a => {
            if (typeof a === 'string') return a;
            if (a && typeof a === 'object' && typeof a.message === 'string') return a.message;
            if (a instanceof Error) return a.message || String(a);
            return '';
          }).join(' ');
          if (text && NOISE.some(re => re.test(text))) return;
        } catch { }
        return orig.apply(console, args);
      };
    }
  } catch { }

  // --- 1b. неперехваченные промисы и ошибки окна ---------------------------
  // Chrome пишет их в панель "Ошибки" напрямую, мимо console.*,
  // поэтому ловим события и гасим только известный шум.
  try {
    const isNoise = text => !!text && NOISE.some(re => re.test(text));

    window.addEventListener('unhandledrejection', event => {
      try {
        const reason = event && event.reason;
        const text = reason && (reason.message || String(reason));
        if (isNoise(text)) {
          event.preventDefault();
          event.stopImmediatePropagation();
        }
      } catch { }
    }, true);

    window.addEventListener('error', event => {
      try {
        const text = (event && (event.message ||
          (event.error && event.error.message))) || '';
        if (isNoise(text)) {
          event.preventDefault();
          event.stopImmediatePropagation();
        }
      } catch { }
    }, true);
  } catch { }

  // --- 2. защита от мёртвого контекста расширения --------------------------
  try {
    const rt = typeof chrome !== 'undefined' && chrome && chrome.runtime;
    if (!rt) return;

    const wrap = (name, fallback) => {
      let orig;
      try { orig = rt[name]; } catch { return; }
      if (typeof orig !== 'function') return;
      try {
        rt[name] = function (...args) {
          try { return orig.apply(rt, args); }
          catch (e) { return typeof fallback === 'function' ? fallback.apply(rt, args) : undefined; }
        };
      } catch { }
    };

    wrap('getURL', () => '');
    wrap('getManifest', () => ({}));
    wrap('sendMessage', () => new Promise(() => { }));

    try {
      const local = chrome.storage && chrome.storage.local;
      if (local) {
        ['get', 'set', 'remove'].forEach(m => {
          const orig = local[m];
          if (typeof orig !== 'function') return;
          local[m] = function (...args) {
            try { return orig.apply(local, args); }
            catch (e) { return m === 'get' ? Promise.resolve({}) : Promise.resolve(); }
          };
        });
      }
    } catch { }
  } catch { }
})();
